﻿// C++/WinRT v1.0.171013.2
// Copyright (c) 2017 Microsoft Corporation. All rights reserved.

#pragma once
#include "winrt/base.h"

WINRT_WARNING_PUSH
#include "winrt/Windows.Foundation.h"
#include "winrt/Windows.Foundation.Collections.h"
#include "winrt/impl/Windows.UI.Xaml.Automation.Text.2.h"
#include "winrt/Windows.UI.Xaml.Automation.h"

namespace winrt::impl {

}

WINRT_EXPORT namespace winrt::Windows::UI::Xaml::Automation::Text {

}

WINRT_EXPORT namespace std {

}

WINRT_WARNING_POP
